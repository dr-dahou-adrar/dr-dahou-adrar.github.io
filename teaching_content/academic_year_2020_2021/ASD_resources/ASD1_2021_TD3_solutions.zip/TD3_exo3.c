#include <stdio.h>

int main()
{ 
    float N,P = 0.0;
    printf("Donner le nombre N: "); 
    scanf("%f", &N); 

    if( N <= 5 ){
        P = 8 * N;
    }
        
    else{

        if( (N > 5) && (N <= 10)){
            P = 40 + (N-5) * 6;
        }
        else
        {
            P = 70 + (N-10) * 5.5;
        }
        
    }

    printf("P est: %.2f.", P); 

}