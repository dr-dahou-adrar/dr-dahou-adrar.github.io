#include <stdio.h>

int main()
{ 

    int N,tmp =0;
    int cmp=1;
    printf("Donner le nombre N: "); 
    scanf("%d", &N); 

    do
    {
        tmp = N + cmp;
        printf("%d ", tmp);
        cmp += 1;
    }while (cmp<=10);
}