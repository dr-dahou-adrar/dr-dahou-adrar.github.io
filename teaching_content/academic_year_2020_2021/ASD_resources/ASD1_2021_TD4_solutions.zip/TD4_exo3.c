#include<stdio.h>

int main(){

	int age,i = 0;
    int som = 0;
    float moyenne = 0.0;
    char resp;

    do
    {
        printf ("entrer l'age: ") ;
	    scanf("%d" ,&age);
        som = som + age;
        i += 1;
        printf ("encore une autre personne (O/N)?") ;
	    scanf(" %c" ,&resp);
    } while (resp == 'O' || resp == 'o');

    moyenne = som / i;
    printf ("La moyenne est: %.2f", moyenne) ;
}