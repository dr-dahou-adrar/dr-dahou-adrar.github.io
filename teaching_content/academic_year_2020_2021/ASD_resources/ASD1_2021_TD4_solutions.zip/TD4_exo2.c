#include<stdio.h>

int main(){

	int n = 0;
    int PG = 0;

    do
    {
        printf ("entrer un nombre: ") ;
	    scanf("%d" ,&n);
        if (n > PG)
        {
            PG = n;
        }

    } while (n != 0);
    printf ("Le plus grand nombre est: %d", PG) ;
}