#include<stdio.h>

int main(){

	int n = 0;
    int i = 1;
    int som = 0;

    printf ("entrer un nombre: ") ;
    scanf("%d" ,&n);
    do
    {
        som = som + i;
        i += 1;

    } while (i <= n);
    printf ("La somme est: %d", som);
}